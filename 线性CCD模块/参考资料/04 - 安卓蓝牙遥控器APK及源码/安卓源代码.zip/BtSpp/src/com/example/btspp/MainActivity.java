package com.example.btspp;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	private UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");
	private BluetoothAdapter mAdapter; //���������������������豸
	private Button btnOpen;
	private Button btnSearch;
	private ImageButton btnLeftUp;
	private ImageButton btnUp;
	private ImageButton btnRightUp;
	private ImageButton btnLeft;
	private ImageButton btnStop;
	private ImageButton btnRight;
	private ImageButton btnLeftDown;
	private ImageButton btnDown;
	private ImageButton btnRightDown;
	private ListView listView;
	private ArrayAdapter<String> arrayAdapter;
	private List<String> listData = new ArrayList<String>();
	private BluetoothSocket socket;  //�����׽���
	private DataThread dataThread;   //�������ݴ����߳�
	private int iDelay; //������ʱ

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		btnOpen = (Button)findViewById(R.id.buttonOpen);
		btnSearch = (Button)findViewById(R.id.buttonSearch);
		btnLeftUp = (ImageButton)findViewById(R.id.imageButtonLU);
		btnUp = (ImageButton)findViewById(R.id.imageButtonU);
		btnRightUp = (ImageButton)findViewById(R.id.imageButtonRU);		
		btnLeft = (ImageButton)findViewById(R.id.imageButtonL);
		btnStop = (ImageButton)findViewById(R.id.imageButtonStop);
		btnRight = (ImageButton)findViewById(R.id.imageButtonR);
		btnLeftDown = (ImageButton)findViewById(R.id.imageButtonLD);
		btnDown = (ImageButton)findViewById(R.id.imageButtonD);
		btnRightDown = (ImageButton)findViewById(R.id.imageButtonRD);		
		
		btnLeftUp.setOnTouchListener(new OnTouchListener() 
		{		
			@Override
			public boolean onTouch(View v, MotionEvent event) 			
			{
				switch (event.getAction()) 
				{
				case MotionEvent.ACTION_DOWN:
					SendData(1);
					break;
				case MotionEvent.ACTION_UP:
					SendData(0);
					break;
				default:
					break;
				}
				return true;
			}
		});
		
		btnUp.setOnTouchListener(new OnTouchListener() 
		{		
			@Override
			public boolean onTouch(View v, MotionEvent event) 			
			{
				switch (event.getAction()) 
				{
				case MotionEvent.ACTION_DOWN:
					SendData(2);
					break;
				case MotionEvent.ACTION_UP:
					SendData(0);
					break;
				default:
					break;
				}
				return true;
			}
		});
		
		btnRightUp.setOnTouchListener(new OnTouchListener() 
		{		
			@Override
			public boolean onTouch(View v, MotionEvent event) 			
			{
				switch (event.getAction()) 
				{
				case MotionEvent.ACTION_DOWN:
					SendData(3);
					break;
				case MotionEvent.ACTION_UP:
					SendData(0);
					break;
				default:
					break;
				}
				return true;
			}
		});
		
		btnLeft.setOnTouchListener(new OnTouchListener() 
		{		
			@Override
			public boolean onTouch(View v, MotionEvent event) 			
			{
				switch (event.getAction()) 
				{
				case MotionEvent.ACTION_DOWN:
					SendData(4);
					break;
				case MotionEvent.ACTION_UP:
					SendData(0);
					break;
				default:
					break;
				}
				return true;
			}
		});
		
		btnRight.setOnTouchListener(new OnTouchListener() 
		{		
			@Override
			public boolean onTouch(View v, MotionEvent event) 			
			{
				switch (event.getAction()) 
				{
				case MotionEvent.ACTION_DOWN:
					SendData(5);
					break;
				case MotionEvent.ACTION_UP:
					SendData(0);
					break;
				default:
					break;
				}
				return true;
			}
		});
		
		btnLeftDown.setOnTouchListener(new OnTouchListener() 
		{		
			@Override
			public boolean onTouch(View v, MotionEvent event) 			
			{
				switch (event.getAction()) 
				{
				case MotionEvent.ACTION_DOWN:
					SendData(6);
					break;
				case MotionEvent.ACTION_UP:
					SendData(0);
					break;
				default:
					break;
				}
				return true;
			}
		});
		
		btnDown.setOnTouchListener(new OnTouchListener() 
		{		
			@Override
			public boolean onTouch(View v, MotionEvent event) 			
			{
				switch (event.getAction()) 
				{
				case MotionEvent.ACTION_DOWN:
					SendData(7);
					break;
				case MotionEvent.ACTION_UP:
					SendData(0);
					break;
				default:
					break;
				}
				return true;
			}
		});
		
		btnRightDown.setOnTouchListener(new OnTouchListener() 
		{		
			@Override
			public boolean onTouch(View v, MotionEvent event) 			
			{
				switch (event.getAction()) 
				{
				case MotionEvent.ACTION_DOWN:
					SendData(8);
					break;
				case MotionEvent.ACTION_UP:
					SendData(0);
					break;
				default:
					break;
				}
				return true;
			}
		});
		
		btnSearch.setEnabled(false);
		btnLeftUp.setEnabled(false);
		btnUp.setEnabled(false);
		btnRightUp.setEnabled(false);	
		btnLeft.setEnabled(false);
		btnRight.setEnabled(false);
		btnLeftDown.setEnabled(false);
		btnDown.setEnabled(false);
		btnRightDown.setEnabled(false);
		btnStop.setEnabled(false);
				
		mAdapter = BluetoothAdapter.getDefaultAdapter();  //��ȡ���������豸		
		listView = (ListView)findViewById(R.id.listView);	
		arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listData);
		listView.setAdapter(arrayAdapter);
		listView.setOnItemClickListener(new ItemClickEvent());	
		
		IntentFilter filter  = new IntentFilter(BluetoothDevice.ACTION_FOUND); 
		registerReceiver(mReceiver, filter);	
		
		iDelay = 20;
	}

	public void OnClickOpen(View v) 
	{	
		if (mAdapter == null)
		{
			Toast.makeText(this, "have no bluetooth device", Toast.LENGTH_SHORT).show();
		}
		else 
		{
			if (!mAdapter.isEnabled())  
			{
				mAdapter.enable();  //���豸
				btnOpen.setText("Close");
				Toast.makeText(this, "open success", Toast.LENGTH_SHORT).show();
				btnSearch.setEnabled(true);
			}
			else 
			{			
				listData.clear();
				listView.removeAllViewsInLayout();
				mAdapter.disable(); //�ر��豸
				btnOpen.setText("Open");
				btnSearch.setEnabled(false);
				btnLeftUp.setEnabled(false);
				btnUp.setEnabled(false);
				btnRightUp.setEnabled(false);	
				btnLeft.setEnabled(false);
				btnRight.setEnabled(false);
				btnLeftDown.setEnabled(false);
				btnDown.setEnabled(false);
				btnRightDown.setEnabled(false);
				btnStop.setEnabled(false);
			}
		}
		
	}
	
	public void OnClickSearch(View v) //�����豸
	{	
		listData.clear();
		if (mAdapter.isDiscovering())
		{
			mAdapter.cancelDiscovery();
		}
		mAdapter.startDiscovery();	
	}
	
	private BroadcastReceiver mReceiver = new BroadcastReceiver() 
	{		
		@Override
		public void onReceive(Context context, Intent intent) 
		{
			String action = intent.getAction();
			if (BluetoothDevice.ACTION_FOUND.equals(action)) //�����豸
			{
				BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
				listData.add(device.getName() + " " + device.getAddress());
				arrayAdapter.notifyDataSetChanged();
			}
		}
	};
	
	class ItemClickEvent implements AdapterView.OnItemClickListener //�����豸
	{
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) 
		{	
			mAdapter.cancelDiscovery(); //ֹͣ����
			
			String strItem = listData.get(arg2);
			String[] strs = strItem.split(" ");
			String address = strs[1];
			BluetoothDevice device = mAdapter.getRemoteDevice(address);		
			
			try 
			{
				socket = device.createRfcommSocketToServiceRecord(MY_UUID); //�����׽���
			} 
			catch (Exception e) 
			{
				Toast.makeText(MainActivity.this, "create socket error", Toast.LENGTH_SHORT).show();
				return;
			} 						
		
			try 
			{				
				socket.connect(); //�����豸 
				Toast.makeText(MainActivity.this, "connect success", Toast.LENGTH_SHORT).show();			
				dataThread = new DataThread(socket); //�������ݷ��ͽ����߳�
				dataThread.start();
				
				btnLeftUp.setEnabled(true);
				btnUp.setEnabled(true);
				btnRightUp.setEnabled(true);	
				btnLeft.setEnabled(true);
				btnRight.setEnabled(true);
				btnLeftDown.setEnabled(true);
				btnDown.setEnabled(true);
				btnRightDown.setEnabled(true);
				btnStop.setEnabled(true);
			} 			
			catch (IOException e)
			{
				Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
				return;
			} 				
		}
		
	}
	
	public class DataThread extends Thread //���ݽ��պͷ����߳�
	{
		private final BluetoothSocket mSocket;
		private final OutputStream mOutputStream;
		
		public DataThread(BluetoothSocket socket)
		{
			mSocket = socket;
			OutputStream tempOutputStream = null;
			
			try 
			{
				tempOutputStream = mSocket.getOutputStream();
			} 
			catch (IOException e) 
			{
				Toast.makeText(MainActivity.this, "get input and output stream error", Toast.LENGTH_SHORT).show();
			}
			
			mOutputStream = tempOutputStream;
		}	 
		
	/*	public void run() //��������
		{			
			while (true)
			{				

			}
		}  */
		
		public void write(byte[] bytes) //��������
		{
			try 
			{
				mOutputStream.write(bytes);
			} 
			catch (IOException e) 
			{
				Toast.makeText(MainActivity.this, "send data error", Toast.LENGTH_SHORT).show();
			}
		}
		
		public void cancel()
		{		
			try 
			{
				if (mSocket.isConnected())
				{
					mSocket.close();
				}
			} 
			catch (IOException e) 
			{
				Toast.makeText(MainActivity.this, "close socket error", Toast.LENGTH_SHORT).show();
			}
		}
		
	}	
	
	public void SendData(int iType) 
	{
		byte[] byteSend = new byte[7];
		byteSend[0] = 0x5a;
		byteSend[1] = (byte)0xa5;
		byteSend[2] = 0x04;
		byteSend[3] = 0x00;
		byteSend[4] = 0x00;
		byteSend[5] = 0x04;
		byteSend[6] = (byte)0xaa;
		switch (iType)
		{
		case 0: //Stop
			byteSend[3] = 0x00;
			byteSend[4] = 0x00;
			byteSend[5] = 0x04;
		break;
		case 1: //L-U
			byteSend[3] = 0x01;
			byteSend[4] = 0x01;
			byteSend[5] = 0x06;
		break;
		case 2: //U
			byteSend[3] = 0x01;
			byteSend[4] = 0x00;
			byteSend[5] = 0x05;
		break;
		case 3: //R-U
			byteSend[3] = 0x01;
			byteSend[4] = 0x02;
			byteSend[5] = 0x07;
		break;
		case 4: //L
			byteSend[3] = 0x00;
			byteSend[4] = 0x01;
			byteSend[5] = 0x05;
		break;
		case 5: //R
			byteSend[3] = 0x00;
			byteSend[4] = 0x02;
			byteSend[5] = 0x06;
		break;
		case 6: //L-D
			byteSend[3] = 0x02;
			byteSend[4] = 0x01;
			byteSend[5] = 0x07;
		break;
		case 7: //D
			byteSend[3] = 0x02;
			byteSend[4] = 0x00;
			byteSend[5] = 0x06;
		break;
		case 8: //R-D
			byteSend[3] = 0x02;
			byteSend[4] = 0x02;
			byteSend[5] = 0x08;
		break;
		default:
		break;
		}
		for (int i=0; i<2; i++)
		{				
			try 
			{
				dataThread.write(byteSend);
				Thread.sleep(iDelay);
	        } 
			catch (InterruptedException e)
			{
				Toast.makeText(this, "sleep error", Toast.LENGTH_SHORT).show();
	        }			
		}
	}
	
	@Override
	protected void onDestroy() 
	{
		if (mAdapter.isEnabled())
		{
			mAdapter.disable();	 //�ر�����
		}		
	    this.unregisterReceiver(mReceiver);
		super.onDestroy();
		android.os.Process.killProcess(android.os.Process.myPid());
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
